Pathologic
----------

Project Page:
http://drupal.org/project/pathologic

By Garrett Albright
http://drupal.org/user/191212

Originally sponsored by Precision Intermedia
http://www.precisionintermedia.com/

Thanks to all who have used this module over the years and provided bug reports
and suggestions via email and the issue queue! I love you all.

Installation & Configuration
----------------------------

For full installation and configuration instructions, please see this page in
the Drupal online manual:
http://drupal.org/node/257026
