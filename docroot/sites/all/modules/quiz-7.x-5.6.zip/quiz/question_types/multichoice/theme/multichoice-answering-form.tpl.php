<?php

/**
 * @file
 * Handles the layout of the multichoice answering form.
 *
 * Variables available:
 * - $form.
 */
print drupal_render($form);
