Remove Generator META tag

USAGE
-----
- Enable to remove the Generator META tag.
- Disable to restore the Generator META tag.
- No configuration required!

Please, represent Drupal whenever possible!
